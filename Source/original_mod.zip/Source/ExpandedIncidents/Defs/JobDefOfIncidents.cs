﻿using RimWorld;
using Verse;

namespace ExpandedIncidents
{
    [DefOf]
    public static class JobDefOfIncidents
    {
        public static JobDef Sabotage;
    }
}
