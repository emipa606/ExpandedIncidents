﻿using RimWorld;

namespace ExpandedIncidents
{
    [DefOf]
    public static class ThoughtDefOfIncidents
    {
        public static ThoughtDef Quarrel;
        public static ThoughtDef Homesickness;
        public static ThoughtDef Clique;
        public static ThoughtDef CliqueFollower;
    }
}
