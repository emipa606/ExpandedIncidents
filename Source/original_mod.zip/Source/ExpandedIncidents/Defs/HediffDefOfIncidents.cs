﻿using RimWorld;
using Verse;

namespace ExpandedIncidents
{
    [DefOf]
    public static class HediffDefOfIncidents
    {
        public static HediffDef PotentialSaboteur;
        public static HediffDef Saboteur;
        public static HediffDef Thief;
    }
}
